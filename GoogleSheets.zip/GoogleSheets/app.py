from urllib import request

from flask import Flask, request
from flask_restful import Resource, Api
import gspread

app = Flask("GoogleSheetsAPI")
api = Api(app)


class GoogleSheets(Resource):

    def readData(self, subject_name):
        sa = gspread.service_account("%APPDATA%/gspread/service_account.json")
        sh = sa.open("attendance app")
        wks = sh.worksheet(subject_name)

        return wks.get("A2:Q18")

    def get(self, subject_name):
        data = self.readData(subject_name)
        print(data)
        return data

    def post(self):
        json_data = request.get_json()
        






api.add_resource(GoogleSheets, '/<subject_name>')

if __name__ == '__main__':
    app.run()